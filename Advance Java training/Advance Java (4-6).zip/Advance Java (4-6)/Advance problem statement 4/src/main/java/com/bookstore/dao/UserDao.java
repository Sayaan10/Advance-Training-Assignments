package com.bookstore.dao;



	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Timestamp;

	import com.bookstore.entity.User;
	public class UserDao {
		private Connection con;

		public UserDao(Connection con) {
			this.con = con;
		}
	public UserDao(String first_name, String address, String email, String uname, String pass) {
			// TODO Auto-generated constructor stub
		}
		//	method to insert in database
		public boolean saveUser(UserDao user) {
			boolean f=false;

			try {
				String query="insert into users(first_name,address,email,user_name,password)values (?,?,?,?,?)";
				PreparedStatement pstmt	=this.con.prepareStatement(query);
				pstmt.setString(1,user.getFirst_name());
				pstmt.setString(2,user.getAddress());
				pstmt.setString(3,user.getEmail());
				pstmt.setString(4,user.getUname());
				pstmt.setString(5,user.getPass());
				
				pstmt.executeUpdate();
				f=true;
			
			} catch (Exception e) {
				e.printStackTrace();
			}
			return f;

		}
		private String getAddress() {
			// TODO Auto-generated method stub
			return null;
		}
		private String getUname() {
			// TODO Auto-generated method stub
			return null;
		}
		private String getPass() {
			// TODO Auto-generated method stub
			return null;
		}
		private String getEmail() {
			// TODO Auto-generated method stub
			return null;
		}
		private String getFirst_name() {
			// TODO Auto-generated method stub
			return null;
		}
		public UserDao getUserByUnameAndPassword(String uname, String password) {
			UserDao user=null;
			try {
				String query="select * from users where user_name=? and password=?";
				
				PreparedStatement psmt=con.prepareStatement(query);
				psmt.setString(1, uname);
				psmt.setString(2, password);
				
				ResultSet set=psmt.executeQuery();
				
				if(set.next()) {
					user=new UserDao(con);
					//data from db
					user.setFirst_name(set.getString("fname"));
					//set to user object
					user.setAddress(set.getString("address"));
					user.setEmail(set.getString("email"));
					user.setFirst_name(uname);
					user.setAddress(set.getString("password"));
					user.setRegdate(set.getTimestamp("rdate"));
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
			
			
			
			return user;
		}
		private void setRegdate(Timestamp timestamp) {
			// TODO Auto-generated method stub
			
		}
		private void setEmail(String string) {
			// TODO Auto-generated method stub
			
		}
		private void setAddress(String string) {
			// TODO Auto-generated method stub
			
		}
		private void setFirst_name(String string) {
			// TODO Auto-generated method stub
			
		}
		

	}
